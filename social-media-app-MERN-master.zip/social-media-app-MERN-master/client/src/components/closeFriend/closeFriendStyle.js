export const styles = {
  "sidebarFriend": {
    "display": "flex",
    "alignItems": "center",
    "marginBottom": "15px"
  },
  "sidebarFriendImg": {
    "width": "32px",
    "height": "32px",
    "borderRadius": "50%",
    "objectFit": "cover",
    "marginRight": "10px"
  }
}