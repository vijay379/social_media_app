export const styles = {
  "messenger": {
    "height": "calc(100vh - 80px)",
    "display": "flex",
    background: '#202a41',
    overflow: 'hidden',
    
  },
}
