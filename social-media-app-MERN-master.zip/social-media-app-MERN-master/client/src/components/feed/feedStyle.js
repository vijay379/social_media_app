export const styles = {
    feed: {
        flex: '5.5',
        background: '#1b2439',
    },
    feedWrapper: {
        padding: '20px',
        background: '#1b2439',
        color: '#d0d3db',
    }
}

